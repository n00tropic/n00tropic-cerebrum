# vsimd

[![Crates.io](https://img.shields.io/crates/v/vsimd.svg)](https://crates.io/crates/vsimd)
[![Docs](https://docs.rs/vsimd/badge.svg)](https://docs.rs/vsimd/)
[![MIT licensed][mit-badge]][mit-url]

[mit-badge]: https://img.shields.io/badge/license-MIT-blue.svg
[mit-url]: ../../LICENSE

⚠️ This crate contains shared implementation details. Do not directly depend on it.
