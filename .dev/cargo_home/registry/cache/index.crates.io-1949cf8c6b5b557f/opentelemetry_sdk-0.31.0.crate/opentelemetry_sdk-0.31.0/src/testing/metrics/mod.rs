//! Structs for tests.
#[doc(hidden)]
pub mod metric_reader;
pub use metric_reader::TestMetricReader;
