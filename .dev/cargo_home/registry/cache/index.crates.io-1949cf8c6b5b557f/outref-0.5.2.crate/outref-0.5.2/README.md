# outref

[![Latest Version]][crates.io]
[![Documentation]][docs.rs] 
![License]

Out reference (`&'a out T`).

[crates.io]: https://crates.io/crates/outref
[Latest Version]: https://img.shields.io/crates/v/outref.svg
[Documentation]: https://docs.rs/outref/badge.svg
[docs.rs]: https://docs.rs/outref
[License]: https://img.shields.io/crates/l/outref.svg

Documentation: <https://docs.rs/outref>

## Contributing

+ [Development Guide](./CONTRIBUTING.md)
+ [Code of Conduct](./CODE_OF_CONDUCT.md)
