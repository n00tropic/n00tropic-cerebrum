# Code of Conduct

This project follows the [Rust Code of Conduct](https://www.rust-lang.org/policies/code-of-conduct).

**ADDITIONAL**: DO NOT submit anything about real world politics.

For example, the political statements in the pages below will be rejected.
+ <https://blog.rust-lang.org/2020/06/04/Rust-1.44.0.html>
+ <https://blog.rust-lang.org/2022/02/24/Rust-1.59.0.html>
+ <https://blog.rust-lang.org/2022/11/03/Rust-1.65.0.html>
