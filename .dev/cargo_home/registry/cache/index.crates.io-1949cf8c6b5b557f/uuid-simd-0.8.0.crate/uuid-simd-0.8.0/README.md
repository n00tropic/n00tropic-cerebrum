# uuid-simd

[![Crates.io](https://img.shields.io/crates/v/uuid-simd.svg)](https://crates.io/crates/uuid-simd)
[![Docs](https://docs.rs/uuid-simd/badge.svg)](https://docs.rs/uuid-simd/)
[![MIT licensed][mit-badge]][mit-url]

[mit-badge]: https://img.shields.io/badge/license-MIT-blue.svg
[mit-url]: ../../LICENSE

SIMD-accelerated UUID operations

Documentation: <https://docs.rs/uuid-simd>

Repository: <https://github.com/Nugine/simd>
